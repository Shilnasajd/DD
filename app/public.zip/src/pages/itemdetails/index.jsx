import React from 'react'
import Header from '../../components/header'
import Footer from '../../components/footer'
import Items from '../../components/items'

const Itemdetails = () => {
  return (
    <>
     
    <Header />
    <Items/>
    <Footer/>
  </>
  )
}

export default Itemdetails