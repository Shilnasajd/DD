# set  up and run

    npm i
    npm run dev

# build 

    npm run build
    