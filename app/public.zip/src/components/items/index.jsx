import React from 'react'
import Hero from '../rentals/Hero'
import Reserve from '../rentals/Reserve'
import ProductDetails from './ProductDetails'

const Items = () => {
  return (
  <>
   <div className="relative z-20 bg-white text-black w-full pt-22 pb-4">
   <ProductDetails/>
    </div>
  
   
  </>
  )
}

export default Items